import React from 'react'
import PageRoute from './../routes/PageRoute';

export default function LayoutContent() {

  return (
    <div>
      <PageRoute />

    </div>
  )
}
