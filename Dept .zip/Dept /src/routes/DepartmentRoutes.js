import React from 'react'
import { Route, Routes } from "react-router-dom";
import constant from '../utils/constant';
import VisitorList from '../pages/Visitor/VisitorList';
import { DepartmentForm } from '../components/CreateDepartment';
import DepartmentList from '../pages/Department/DepartmentList';

export default function DepartmentRoutes() {
    return <Routes>
        <Route index element={ <DepartmentList />} />
        <Route
            path={constant.APP_ROUTES.DEPARTMENT.EDIT_DEPARTMENT}
            element={<DepartmentForm/>} />
        <Route path={constant.APP_ROUTES.DEPARTMENT.ADD_DEPARTMENT} element={<DepartmentForm />} />
    </Routes>
}