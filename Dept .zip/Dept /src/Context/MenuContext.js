import NavItem from '../utils/MenuList'
import  React from 'react';

const MenuContext = React.createContext(NavItem);
export default MenuContext