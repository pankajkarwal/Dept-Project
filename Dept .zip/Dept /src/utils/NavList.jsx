export default{
    HOME:'home',
    VISITOR:'visitor'
}