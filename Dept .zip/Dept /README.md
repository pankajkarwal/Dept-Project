# VMS
MONGO+EXPRESS+REACT+NODE
1. Clone the code repository 
2. cd to vms and run command <strong>npm start</strong> to start react application.
3. cd to vms-api & run command <strong>npm start</strong> to start backend application.
4. Will be using micro-frontend (bit.dev) to use the already created component for our ease.
5. Creating a mongodb Collections for vms database
6. Import the collections inside your mongodb compass
