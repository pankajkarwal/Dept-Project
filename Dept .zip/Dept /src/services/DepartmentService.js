import { Axios } from "../lib/axios"
import constant from "../utils/constant";
import { formatRoute } from 'react-router-named-routes';



const addDepartment = async (payload) => {
    return await Axios.post(constant.SERVICES_ROUTES.DEPARTMENT.ADD_DEPARTMENT,payload);
}
const getDepartments = async () => {
   
   return await Axios.get(constant.SERVICES_ROUTES.DEPARTMENT.FETCH_ALL_DEPARTMENTS)

}
const updateDepartment = async (payload) => {
    return await Axios.put(constant.SERVICES_ROUTES.DEPARTMENT.UPDATE_DEPARTMENT,payload)
}

const getDepartment= async (id) => {
    return await Axios.get(constant.SERVICES_ROUTES.DEPARTMENT.SINGLE_DEPARTMENT + "/" +id)
}


export {
   
    addDepartment,
    getDepartment,
    getDepartments,
updateDepartment,
    }