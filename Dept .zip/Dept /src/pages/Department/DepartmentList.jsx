import React, { useEffect, useState } from 'react'
import * as apiServices from '../../services/DepartmentService'
import { DynamicTable } from '@opensource/bit-scope.dynamic-table'
import constant from '../../utils/constant';
import { useNavigate } from 'react-router-dom';
import { Button, IconButton, Box } from '@mui/material';
import Toast from '../../utils/Toast';
import { formatRoute } from 'react-router-named-routes'
import ConfirmDialog from '../../utils/ConfirmDialog';
import DeleteIcon from '@mui/icons-material/Delete';
import ModeEditIcon from '@mui/icons-material/ModeEdit';
import { DateConversion } from '../../utils/DateConversion';


export default function DepartmentList() {
  const [rows, setRows] = useState([])
  const [vId, setVId] = useState(0);
  const [openBox, setOpenBox] = useState(false);
  const navigate = useNavigate();

  const onDelete = (e) => {
    e.stopPropagation()
    // // Call the api for deleting the visitor record from the database
    // apiServices.deleteDepartment(vId).then((res) => {
    //   if (res && res.data) {
    //     navigate(0);
    //     Toast(constant.SUCCESS.DEPARTMENT.DELETED_DEPARTMENT, 'success')
    //   }
    // }).catch((error) => {
    //   Toast(error && error.data && error.data.error ? error.data.error : constant.ERRORS.DEFAULT_ERROR, 'error')
    // })

  };

  const editPage = (visitorId) => {
    navigate(formatRoute(constant.APP_ROUTES.DEPARTMENT.EDIT_DEPARTMENT, { id: visitorId }));
  }

  const addPage = () => {
    navigate(constant.APP_ROUTES.DEPARTMENT.ADD_DEPARTMENT);
  }

  const columns = [
    { field: 'id', headerName: 'ID', width: 70, headerClassName: 'super-app-theme--header' },

    { field: 'DepartmentID', headerName: 'Department ID', width: 70, headerClassName: 'super-app-theme--header' },
    { field: 'Department', headerName: 'Department', width: 200, headerClassName: 'super-app-theme--header' },
    { field: 'Status', headerName: 'Status', width: 300, headerClassName: 'super-app-theme--header' },
    { field: 'PrintOrder', headerName: 'Print Order', width: 150, headerClassName: 'super-app-theme--header' },
    { field: 'dtEntry', headerName: 'Date of Entry', width: 180, headerClassName: 'super-app-theme--header' },
    {
      field: 'actions', headerName: 'Actions', width: 495, headerClassName: 'super-app-theme--header', renderCell: (params) => {
        return (
          <>
            <IconButton aria-label="edit" onClick={(e) => editPage(params.row.DepartmentID)} >
              <ModeEditIcon />
            </IconButton>
            &nbsp;&nbsp;
            <div>
              <IconButton aria-label="delete" onClick={() => { setOpenBox(true); setVId(params.row.DepartmentID) }}>
                <DeleteIcon />
              </IconButton>
              <ConfirmDialog
                id={params.row._id}
                title={constant.MODELS.DEPARTMENT.DELETE_HEADER}
                open={openBox}
                setOpen={setOpenBox}
                onConfirm={onDelete}
              >
                {constant.MODELS.DEPARTMENT.DELETE_TEXT}
              </ConfirmDialog>
            </div>

          </>
        );
      }
    }
  ]
  useEffect(() => {
    // Component did Mount
    apiServices.getDepartments().then((res) => {
      
      console.log("Called Visitor List",res)
      const filteredData = res && res.data && res.data.data && res.data.data.length > 0 && res.data.data.map((item, i) => {
        if(item.created_at){
          item.created_at = DateConversion(item.created_at,'MMMM Do YYYY, h:mm:ss a')
       }
        return {
          ...item,
          id: i + 1
        }
      });

      setRows(filteredData)
    }).catch((error) => {
      // Dummy Data
    
      const newData =  filteredData.map(obj => ({ ...obj, id: obj.id ? obj.id+1 : 1 }))
      console.log("New Data",newData)
      setRows(newData)
      Toast(error && error.data && error.data.error ? error.data.error : constant.ERRORS.DEFAULT_ERROR, 'error')
    })
    const filteredData = [
      {
        DepartmentID: 1,
        Department: "CLINICAL PATHOLOGY",
        DepartmentCode: "012222",
        Status: "Active",
        PrintOrder: "32",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T14:18:16.000Z"
      },
      {
        DepartmentID: 2,
        Department: "SHE",
        DepartmentCode: "sd",
        Status: "Active",
        PrintOrder: "34",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 3,
        Department: "Yasg",
        DepartmentCode: "2756",
        Status: "Active",
        PrintOrder: "30",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 7,
        Department: "CYTOLOGY",
        DepartmentCode: "CY",
        Status: "Active",
        PrintOrder: "8",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 8,
        Department: "Dental Imaging",
        DepartmentCode: "DI",
        Status: "Active",
        PrintOrder: "22",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 9,
        Department: "ECHO, TMT, PFT & ECG",
        DepartmentCode: "ETPE",
        Status: "Active",
        PrintOrder: "15",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 10,
        Department: "FETAL ORGANS",
        DepartmentCode: "FO",
        Status: "Active",
        PrintOrder: "29",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 11,
        Department: "FIBRO SCAN",
        DepartmentCode: "FS",
        Status: "Active",
        PrintOrder: "13",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 12,
        Department: "HAEMATOLOGY",
        DepartmentCode: "HM",
        Status: "Active",
        PrintOrder: "16",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 13,
        Department: "HISTO PROCESSING",
        DepartmentCode: "HPG",
        Status: "Active",
        PrintOrder: "31",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 14,
        Department: "HISTOPATHOLOGY",
        DepartmentCode: "HP",
        Status: "Active",
        PrintOrder: "25",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 15,
        Department: "IHC Marker",
        DepartmentCode: "IHC",
        Status: "Active",
        PrintOrder: "33",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 16,
        Department: "IMMUNOLOGY",
        DepartmentCode: "IM",
        Status: "Active",
        PrintOrder: "23",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 17,
        Department: "MICROBIOLOGY",
        DepartmentCode: "MI",
        Status: "Active",
        PrintOrder: "35",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 18,
        Department: "MISCELLANEOUS TESTS",
        DepartmentCode: "MC",
        Status: "Active",
        PrintOrder: "20",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 22,
        Department: "NEUROPHYSIOLOGIC STUDIES",
        DepartmentCode: "NPS",
        Status: "Active",
        PrintOrder: "10",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 23,
        Department: "NUCLEAR MEDICINE",
        DepartmentCode: "NM",
        Status: "Active",
        PrintOrder: "21",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 24,
        Department: "OPD PACKAGE",
        DepartmentCode: "OP",
        Status: "Active",
        PrintOrder: "24",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 25,
        Department: "SEROLOGY",
        DepartmentCode: "SE",
        Status: "Active",
        PrintOrder: "19",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 26,
        Department: "SPECIAL TESTS ",
        DepartmentCode: "SP",
        Status: "Active",
        PrintOrder: "17",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 27,
        Department: "SPECIAL ULTRASOUND",
        DepartmentCode: "SU",
        Status: "Active",
        PrintOrder: "27",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 28,
        Department: "ULTRASOUND",
        DepartmentCode: "US",
        Status: "Active",
        PrintOrder: "18",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 29,
        Department: "ULTRASOUND OBS",
        DepartmentCode: "USO",
        Status: "Active",
        PrintOrder: "26",
        dtEntry: "2020-05-05T21:13:39.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 31,
        Department: "BODY FLUIDS",
        DepartmentCode: "BF",
        Status: "Active",
        PrintOrder: "14",
        dtEntry: "2020-08-04T12:53:31.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 32,
        Department: "ENDOCRINOLOGY",
        DepartmentCode: "ENDO",
        Status: "Active",
        PrintOrder: "9",
        dtEntry: "2020-08-04T16:24:43.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 33,
        Department: "ROUTINE PATHOLOGY ",
        DepartmentCode: "ROUPATH",
        Status: "Active",
        PrintOrder: "28",
        dtEntry: "2020-08-04T16:27:43.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 34,
        Department: "CULTURE SENSITIVITY",
        DepartmentCode: "CUL_SEN",
        Status: "Active",
        PrintOrder: "36",
        dtEntry: "2020-08-04T16:42:06.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 35,
        Department: "BIOCHEMISTRY",
        DepartmentCode: "BIO",
        Status: "Active",
        PrintOrder: "11",
        dtEntry: "2020-08-04T16:55:52.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 36,
        Department: "PACKEGES",
        DepartmentCode: "PACK",
        Status: "Active",
        PrintOrder: "12",
        dtEntry: "2020-08-04T17:03:28.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 269,
        Department: "computer Science",
        DepartmentCode: "1996",
        Status: "Active",
        PrintOrder: "1",
        dtEntry: "2023-06-30T07:48:42.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 270,
        Department: "Moin",
        DepartmentCode: "Moin",
        Status: "Active",
        PrintOrder: "4",
        dtEntry: "2023-06-30T15:39:17.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 271,
        Department: "Chemist Dept.",
        DepartmentCode: "90328",
        Status: "Active",
        PrintOrder: "3",
        dtEntry: "2023-07-01T07:07:47.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 272,
        Department: "toxicoogy",
        DepartmentCode: "243",
        Status: "Active",
        PrintOrder: "5",
        dtEntry: "2023-07-01T07:08:15.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 273,
        Department: "CLINICAL PATHO",
        DepartmentCode: "12",
        Status: "Active",
        PrintOrder: "6",
        dtEntry: "2023-07-01T07:08:37.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 274,
        Department: "toxicoogy23",
        DepartmentCode: "122",
        Status: "Active",
        PrintOrder: "7",
        dtEntry: "2023-07-01T07:09:30.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 275,
        Department: "A",
        DepartmentCode: "b",
        Status: "Active",
        PrintOrder: "2",
        dtEntry: "2023-07-04T11:42:23.000Z",
        dtUpdate: "2023-07-04T12:34:38.000Z"
      },
      {
        DepartmentID: 276,
        Department: "ABC",
        DepartmentCode: "",
        Status: "Active",
        PrintOrder: "",
        dtEntry: "2023-07-06T14:04:53.000Z",
        dtUpdate: "0000-00-00 00:00:00"
      }
    ]
  const newData =  filteredData.map((obj,index) => ({ ...obj, id: index+1  }))
  console.log("New Data",newData)
  setRows(newData)
  }, [])
  function Item(props) {
    const { sx, ...other } = props;
    return (
      <Box
        sx={{
          p: 1,
          m: 1,
          fontSize: '0.875rem',
          fontWeight: '700',
          ...sx,
        }}
        {...other}
      />
    );
  }
  return (
    <>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          p: 1,
          m: 1,
          bgcolor: 'background.paper',
          borderRadius: 1,
        }}
      >
        <Item></Item>
        <h4><Item>{constant.PAGES.DEPARTMENT.LIST_PAGE_CAPTION}</Item></h4>
        <Item> <Button variant="contained" onClick={addPage} >{constant.LABEL_CONSTANTS.DEPARTMENT.BTN_ADD_DEPARTMENT}</Button></Item>
      </Box>

      <Box
        sx={{
          '& .super-app-theme--header': {
            backgroundColor: '#3f51b5',
            color: 'white'
          },
        }}
      >
        <DynamicTable
          
          tableStyle={{ height: 600, width: '1000' }}
          checkboxSelection={false}
          columns={columns}
          rows={rows && rows.length > 0 ? rows : []}
          pageSize={constant.TABLE.DEFAULT_PAGE_SIZE}
          rowsPerPageOptions={constant.TABLE.DEFAULT_ROWS_PER_PAGE}
          headerClassName={'super-app-theme--header'}
        />


      </Box>



    </>
  )
}
